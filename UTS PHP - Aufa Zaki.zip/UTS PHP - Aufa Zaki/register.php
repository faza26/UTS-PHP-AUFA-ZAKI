<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Register - SB Admin</title>
    <link href="styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="bg-primary">
    <nav class="sb-topnav navbar navbar-expand navbar-light bg-light">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-3" href=""><img src="alodokter-logo.svg"  width="250" height="350" alt=""></a>
        <!-- Sidebar Toggle-->
        
        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            <div class="input-group">
                <input class="form-control" type="text" placeholder="Tanya Dokter..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
            </div>
        </form>
        <!-- Navbar-->
        <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="#!">Settings</a></li>
                    <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                    <li>
                        <hr class="dropdown-divider" />
                    </li>
                    <li><a class="dropdown-item" href="#!">Logout</a></li>
                </ul>
            </li>
        </ul>
    </nav>


    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-7">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-4">MEDICAL FORM</h3>
                                </div>
                                <div class="card-body">
                                    <form action="p_register.php" method="POST">
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input name="firstname" class="form-control" id="inputFirstName" type="text" placeholder="Enter your first name" />
                                                    <label for="inputFirstName">First name</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input name="lastname" class="form-control" id="inputLastName" type="text" placeholder="Enter your last name" />
                                                    <label for="inputLastName">Last name</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input name="age" class="form-control" id="inputFirstName" type="text" placeholder="Enter your first name" />
                                                    <label for="inputFirstName">What is your age?</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6 d-flex">
                                                <div class="form-check me-3">
                                                    <input name="gender" class="form-check-input" type="radio" id="flexRadioDefault1" value="Laki-laki">
                                                    <label class="form-check-label" for="flexRadioDefault1">
                                                        Laki-laki
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input name="gender" class="form-check-input" type="radio" id="flexRadioDefault1" value="perempuan">
                                                    <label class="form-check-label" for="flexRadioDefault1">
                                                        Perempuan
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input name="email" class="form-control" id="inputEmail" type="email" placeholder="name@example.com" />
                                            <label for="inputEmail">Email address</label>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6 ">
                                                <select class="form-select" aria-label="Default select example" id="agama" name="agama">
                                                    <option selected>Agama</option>
                                                    <option value="Islam">Islam</option>
                                                    <option value="Kristen">Kristen</option>
                                                    <option value="Hindu">Hindu</option>
                                                    <option value="Budha">Budha</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <select class="form-select" aria-label="Default select example" id="pendidikan" name="pendidikan">
                                                    <option selected>Jenjang Pendidikan</option>
                                                    <option value="SD">SD</option>
                                                    <option value="SMP">SMP</option>
                                                    <option value="SMA">SMA</option>
                                                    <option value="S1">S1</option>
                                                    <option value="S2">S2</option>
                                                    <option value="S3">S3</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input name="kota" class="form-control" id="inputFirstName" type="text" placeholder="Enter your first name" />
                                                    <label for="inputFirstName">Nama Kota</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input name="provinsi" class="form-control" id="inputLastName" type="text" placeholder="Enter your last name" />
                                                    <label for="inputLastName">Provinsi</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-header">
                                            <h3 class="text-center font-weight-light my-4">MEDICAL CHECK FORM</h3>
                                        </div>
                                        <p class="mt-3 mb-2">Periksa ketentuan yang berlaku untuk Anda atau anggota
                                            kerabat dekat Anda:
                                        </p>
                                        <div class="form-check-inline">
                                            <input class="form-check-input" type="checkbox" name="ketentuan" value="Asma" id="flexCheckDefault">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                Asma
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <input class="form-check-input" type="checkbox" name="ketentuan" value="Penyakit Jantung" id="flexCheckDefault">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                Penyakit Jantung
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <input class="form-check-input" type="checkbox" name="ketentuan" value="Kanker" id="flexCheckDefault">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                Kanker
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <input class="form-check-input" type="checkbox" name="ketentuan" value="Diabetes" id="flexCheckDefault">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                Diabetes
                                            </label>
                                        </div>

                                        <p class="mt-5 mb-1">Periksa gejala yang Anda alami saat ini:
                                        </p>
                                        <div class="form-check-inline">
                                            <input class="form-check-input" type="checkbox" name="gejala" value="Sakit Dada" id="flexCheckDefault">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                Sakit Dada
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <input class="form-check-input" type="checkbox" name="gejala" value="Kardiovaskulator" id="flexCheckDefault">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                Kardiovaskulator
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <input class="form-check-input" type="checkbox" name="gejala" value="Pernapasan" id="flexCheckDefault">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                Pernapasan
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <input class="form-check-input" type="checkbox" name="gejala" value="Penambahan BB" id="flexCheckDefault">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                Penambahan BB
                                            </label>
                                        </div>
                                        <p class="mt-5 mb-1">Apakah saat ini Anda mengonsumsi obat?
                                        </p>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="mengonsumsi" value="Ya" id="mengonsumsi1">

                                            <label class="form-check-label" for="mengonsumsi1">
                                                Ya
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="mengonsumsi" value="Tidak" id="mengonsumsi2">
                                            <label class="form-check-label" for="mengonsumsi2">
                                                Tidak
                                            </label>
                                        </div>
                                        <div class="mb-3 mt-3">
                                            <label for="exampleFormControlTextarea1" class="form-label">Silahkan List yang lain: </label>
                                            <textarea name="list" class="form-control" id="exampleFormControlTextarea1" rows="1"></textarea>
                                        </div>
                                        <div class="mt-4 mb-0">
                                            <div class="d-grid"><button name="submit" type="submit" value="submit" class="btn btn-primary">Daftar</button></div>
                                        </div>
                                    </form>
                                </div>
                                <div class="card-footer text-center py-3">
                                    <h3 class="text-center font-weight-light my-2"><b>Take care of your health</b> </h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        <div id="layoutAuthentication_footer">
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; AufaZaki2022</div>
                        <div>
                            <a href="#">Privacy Policy</a>
                            &middot;
                            <a href="#">Terms &amp; Conditions</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>

</html>